#include <stdio.h>
#include "gustb.h"
#include <locale.h>

char no_dado[30];
int prio;

main (){
	
	
	for(int x = 0; x<=5; x++){
		dados("oi", 1);
	}
	
	
	
}
