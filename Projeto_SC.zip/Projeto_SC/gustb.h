#ifndef GUSTB_H
#define GUSTB_H

#include <stdio.h>

float soma(){
    float n,m;
    scanf("%f", &n);
    scanf("%f", &m);
    float resu = n + m;
    printf("\nA soma de %f + %f � = %f.\n", n, m, resu);
}

char bdn(){
    char n[20];
    printf("Qual o seu nome?\n");
    scanf("%s", &n);
    printf("Bom dia %s, tenha um �timo dia.\n", n);
}

int fat(int n){
    int resu = 1;
    for(int x = 1; x <= n; x++){
        resu = resu * x;
    }
    return resu;
}

char dados(char d, int p){
	printf("Digite o nome do dado e depois digite 0 se ele tiver prioridade ou 1 se ele tiver prioridade na fila.\n");
	scanf("%s", &d);
	scanf("%d", &p);
	
	return (d, p);
}

#endif
